import { Materia } from './materia';

describe('Materia', () => {
  it('should create an instance', () => {
    expect(new Materia()).toBeTruthy();
  });
});
