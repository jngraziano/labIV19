export class Usuario {

    public nombre: string;
    public email: string;
    public tipo: string;
    public clave: string;
}
