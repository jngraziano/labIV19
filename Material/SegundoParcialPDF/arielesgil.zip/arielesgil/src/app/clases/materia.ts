export class Materia {
    public nombre:string;
    public cuatrimestre:string;
    public cupos:number;
    public profesor: string;
    public emailProfesor:string;
    
}
