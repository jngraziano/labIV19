// This file can be replaced during build by using the `fileReplacements` array.
// `ng build --prod` replaces `environment.ts` with `environment.prod.ts`.
// The list of file replacements can be found in `angular.json`.

export const environment = {
  production: false,
   firebaseConfig : {
    apiKey: "AIzaSyBafVfolW47jS-2n9fIp9hjgMl9osSjSKQ",
    authDomain: "parcial-2-f2cf7.firebaseapp.com",
    databaseURL: "https://parcial-2-f2cf7.firebaseio.com",
    projectId: "parcial-2-f2cf7",
    storageBucket: "parcial-2-f2cf7.appspot.com",
    messagingSenderId: "1002996694162",
    appId: "1:1002996694162:web:25b4ecdd02ee2653ef3a4b",
    measurementId: "G-5PCDGJ5RYJ"
  }
};

/*
 * For easier debugging in development mode, you can import the following file
 * to ignore zone related error stack frames such as `zone.run`, `zoneDelegate.invokeTask`.
 *
 * This import should be commented out in production mode because it will have a negative impact
 * on performance if an error is thrown.
 */
// import 'zone.js/dist/zone-error';  // Included with Angular CLI.
